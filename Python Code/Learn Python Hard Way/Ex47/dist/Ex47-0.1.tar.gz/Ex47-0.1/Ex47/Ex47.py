def print_H(str = "HELLO WORLD"):
    print(str)
